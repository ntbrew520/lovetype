// web/config.js
// ← RenderのあなたのAPI URLに差し替えてください（末尾スラッシュ不要）
window.API_BASE = "https://lovetype.onrender.com";
